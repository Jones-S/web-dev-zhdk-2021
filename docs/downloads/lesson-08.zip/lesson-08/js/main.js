document.addEventListener('DOMContentLoaded', () => {
  console.log('The DOM is ready.');

  /**
  select and console.log div with class .select-me
  select and console.log h2 inside of .select-me
  select and console.log the last table cell
  */

});